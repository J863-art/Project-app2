<?php $__env->startSection('container'); ?>
<div class="container mt-4">
    <div class="card shadow-lg border-primary mb-3">
        <div class="card-body">
            <h5 class="card-title">Detail Rapat</h5>
            <ul class="list-unstyled">
                <li><strong>Tanggal:</strong> <?php echo e($rapat->tanggal); ?></li>
                <li><strong>Judul:</strong> <?php echo e($rapat->judul); ?></li>
                <li><strong>Alamat:</strong> <?php echo e($rapat->alamat); ?></li>
                <li><strong>Keputusan:</strong> <?php echo e($rapat->keputusan); ?></li>
                <?php if($rapat->dokumentasi): ?>
                    <li>
                        <strong>Dokumentasi:</strong>
                        <a href="<?php echo e(route('rapat.download', $rapat->id)); ?>" class="btn btn-primary">Download PDF</a>
                    </li>
                <?php else: ?>
                    <li><strong>Dokumentasi:</strong> Tidak ada dokumentasi tersedia.</li>
                <?php endif; ?>
            </ul>
            <a href="<?php echo e(route('rapat.index')); ?>" class="btn btn-primary mt-3">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/rapat/detailrapat.blade.php ENDPATH**/ ?>