<?php $__env->startSection('container'); ?>

<div class="container">

    <h2>Daftar Tagihan</h2>

    <!-- Tombol untuk membuat tagihan baru -->
    <a href="<?php echo e(route('tagihanadmin.create')); ?>" class="btn btn-success mb-3">Buat Tagihan Baru</a>

    <table class="table">
        <thead>
            <tr>
                <th>NIK</th>
                <th>Jenis Tagihan</th>
                <th>Status</th>
                <th>Jatuh Tempo</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tagihans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tagihan->nik); ?></td>
                <td><?php echo e($tagihan->jenis_tagihan); ?></td>
                <td><?php echo e($tagihan->status); ?></td>
                <td><?php echo e($tagihan->jatuh_tempo); ?></td>
                <td>
                    <a href="<?php echo e(route('tagihanadmin.edit', $tagihan->id)); ?>" class="btn btn-primary">Detail</a>

                    <!-- Tombol Delete -->
                    <form action="<?php echo e(route('tagihanadmin.destroy', $tagihan->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus tagihan ini?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/tagihanadmin/index.blade.php ENDPATH**/ ?>