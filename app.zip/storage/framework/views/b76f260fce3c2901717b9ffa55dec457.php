<?php $__env->startSection('container'); ?>
<div class="container">
    <h2>Detail Tagihan</h2>
    <table class="table">
        <tr>
            <th>NIK</th>
            <td><?php echo e($tagihan->nik); ?></td>
        </tr>
        <tr>
            <th>Jenis Tagihan</th>
            <td><?php echo e($tagihan->jenis_tagihan); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo e($tagihan->status); ?></td>
        </tr>
        <tr>
            <th>Jatuh Tempo</th>
            <td><?php echo e($tagihan->jatuh_tempo); ?></td>
        </tr>
        <tr>
            <th>Bukti Pembayaran</th>
            <td>
                <?php if($tagihan->bukti_pembayaran): ?>
                    <a href="<?php echo e(route('tagihanadmin.download', $tagihan->id)); ?>" class="btn btn-primary">Download Bukti Pembayaran</a>
                <?php else: ?>
                    <span>Tidak ada bukti pembayaran</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    



    <!-- Form untuk update detail tagihan -->
    <form action="<?php echo e(route('tagihanadmin.update', $tagihan->id)); ?>" method="POST" class="mt-5">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <h3>Update Detail Tagihan</h3>
        <div class="form-group">
            <label for="nik">NIK:</label>
            <input type="text" name="nik" class="form-control" value="<?php echo e($tagihan->nik); ?>" required readonly>
        </div>
        <div class="form-group">
            <label for="jenis_tagihan">Jenis Tagihan:</label>
            <input type="text" name="jenis_tagihan" class="form-control" value="<?php echo e($tagihan->jenis_tagihan); ?>" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <input type="text" name="status" class="form-control" value="<?php echo e($tagihan->status); ?>" required>
        </div>
        <div class="form-group">
            <label for="jatuh_tempo">Jatuh Tempo:</label>
            <input type="date" name="jatuh_tempo" class="form-control" value="<?php echo e($tagihan->jatuh_tempo); ?>" required>
        </div>
        <button type="submit" class="btn btn-info mt-2">Update Tagihan</button>
    </form>

    <a href="<?php echo e(route('tagihanadmin.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\tagihanadmin\edit.blade.php ENDPATH**/ ?>