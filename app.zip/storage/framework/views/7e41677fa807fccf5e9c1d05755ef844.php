<?php $__env->startSection('container'); ?>

    <h1>Halaman Acara</h1> <!-- Menampilkan judul yang disediakan oleh controller -->

    <table class="table">
        <thead>
            <tr>
                <th>Judul Acara</th>
                <th>Alamat</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($event->event_name); ?></td>
                    <td><?php echo e($event->address); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($event->schedule)->format('d-m-Y H:i')); ?></td> <!-- Konversi ke Carbon di sini -->
                    <td><?php echo e($event->ket); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\events\index.blade.php ENDPATH**/ ?>