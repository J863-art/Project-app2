<?php $__env->startSection('container'); ?>
<div class="container">
    <h2>Buat Tagihan Baru</h2>

    <form action="<?php echo e(route('tagihanadmin.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nik">NIK:</label>
            <input type="text" name="nik" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="jenis_tagihan">Jenis Tagihan:</label>
            <input type="text" name="jenis_tagihan" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <input type="text" name="status" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="jatuh_tempo">Jatuh Tempo:</label>
            <input type="date" name="jatuh_tempo" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success mt-2">Simpan Tagihan</button>
    </form>

    <a href="<?php echo e(route('tagihanadmin.index')); ?>" class="btn btn-secondary mt-3">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/tagihanadmin/create.blade.php ENDPATH**/ ?>