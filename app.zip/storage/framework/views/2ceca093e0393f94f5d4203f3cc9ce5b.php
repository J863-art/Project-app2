<?php $__env->startSection('container'); ?>

<div class="container">

    <h1>Edit Rapat</h1>

    <form action="<?php echo e(route('rapatadmin.update', $rapat)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?php echo e($rapat->tanggal); ?>" required>
        </div>

        <div class="mb-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e($rapat->judul); ?>" required>
        </div>

        <div class="mb-3">
            <label for="alamat" class="form-label">Lokasi</label>
            <input type="text" class="form-control" id="alamat" name="alamat" value="<?php echo e($rapat->alamat); ?>" required>
        </div>

        <div class="mb-3">
            <label for="keputusan" class="form-label">Keputusan</label>
            <textarea class="form-control" id="keputusan" name="keputusan" required><?php echo e($rapat->keputusan); ?></textarea>
        </div>

        <div class="mb-3">
            <label for="dokumentasi" class="form-label">Dokumentasi (PDF)</label>
            <input type="file" class="form-control" id="dokumentasi" name="dokumentasi" accept="application/pdf">
        </div>

        <button type="submit" class="btn btn-primary">Perbarui Rapat</button>
        <a href="<?php echo e(route('rapatadmin.index')); ?>" class="btn btn-secondary">Kembali</a>
    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/rapatadmin/edit.blade.php ENDPATH**/ ?>