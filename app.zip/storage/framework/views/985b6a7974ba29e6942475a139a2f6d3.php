<?php $__env->startSection('Halaman awal'); ?>
    <h1>Halaman home</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\home.blade.php ENDPATH**/ ?>