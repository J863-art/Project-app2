<?php $__env->startSection('container'); ?>
    <article>
        <h2><?php echo e($artik->title); ?></h2>

        <p>By: <a href="/authors/<?php echo e($artik->author->username); ?>" class="text-decoration-none"><?php echo e($artik->author->name); ?></a></p>

        <?php echo $artik->body; ?>

    </article>

    <a href="/artikel">Back to Artikel</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\artik.blade.php ENDPATH**/ ?>