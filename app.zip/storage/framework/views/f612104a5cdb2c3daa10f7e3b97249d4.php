<?php $__env->startSection('container'); ?>

    <h1>Halaman Acara</h1>

    <!-- Tombol Tambah Acara -->
    <a href="<?php echo e(route('eventadmin.create')); ?>" class="btn btn-success mb-3">Tambah Acara</a>

    <table class="table">
        <thead>
            <tr>
                <th>Judul Acara</th>
                <th>Alamat</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($event->event_name); ?></td>
                    <td><?php echo e($event->address); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($event->schedule)->format('d-m-Y H:i')); ?></td>
                    <td><?php echo e($event->ket); ?></td>
                    <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('eventadmin.show', $event->id)); ?>" class="btn btn-info me-2">Detail</a>
                            <form action="<?php echo e(route('eventadmin.destroy', $event->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus acara ini?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/eventadmin/index.blade.php ENDPATH**/ ?>