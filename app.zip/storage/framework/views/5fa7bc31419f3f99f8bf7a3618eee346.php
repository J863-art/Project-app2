<?php $__env->startSection('container'); ?>

<div class="container">

    <h2>Daftar Tagihan</h2>

    <table class="table">
        <thead>
            <tr>
                <th>Jenis Tagihan</th>
                <th>Status</th>
                <th>Jatuh Tempo</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tagihans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tagihan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($tagihan->jenis_tagihan); ?></td>
                <td><?php echo e($tagihan->status); ?></td>
                <td><?php echo e($tagihan->jatuh_tempo); ?></td>
                <td>
                    <a href="<?php echo e(route('tagihan.show', $tagihan->id)); ?>" class="btn btn-primary">Detail</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/tagihan/index.blade.php ENDPATH**/ ?>