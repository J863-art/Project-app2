<?php $__env->startSection('Halaman awal'); ?>
<h1 class="mb-5">Kategori Artikel : <?php echo e($category); ?> </h1>
    <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <article class="mb-5">
        <h2>
            <a href="/artikel/<?php echo e($artik->slug); ?>"><?php echo e($artik->title); ?></a></h2>
            <p><?php echo e($artik->excerpt); ?></p>

    </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\category.blade.php ENDPATH**/ ?>