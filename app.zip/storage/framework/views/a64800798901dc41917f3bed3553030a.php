<?php $__env->startSection('container'); ?>

    <h1>Detail Acara</h1>

    <form action="<?php echo e(route('eventadmin.update', $event->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label for="event_name" class="form-label">Judul Acara</label>
            <input type="text" class="form-control" id="event_name" name="event_name" value="<?php echo e($event->event_name); ?>" required>
        </div>

        <div class="mb-3">
            <label for="address" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="address" name="address" value="<?php echo e($event->address); ?>" required>
        </div>

        <div class="mb-3">
            <label for="schedule" class="form-label">Tanggal</label>
            <input type="datetime-local" class="form-control" id="schedule" name="schedule" value="<?php echo e(\Carbon\Carbon::parse($event->schedule)->format('Y-m-d\TH:i')); ?>" required>
        </div>

        <div class="mb-3">
            <label for="ket" class="form-label">Keterangan</label>
            <textarea class="form-control" id="ket" name="ket" rows="3" required><?php echo e($event->ket); ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\eventadmin\show.blade.php ENDPATH**/ ?>