<?php $__env->startSection('container'); ?>

<h1 class="mb-5">Halaman Artikel</h1>

    <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <article class="mb-5 border-bottom pb-4">

        <h2>
            <a href="/artikel/<?php echo e($artik->slug); ?>" class="text-decoration-none"><?php echo e($artik->title); ?></a>
        </h2>

        <?php if($artik->author): ?>
            <p>By: <a href="/authors/<?php echo e($artik->author->username); ?>" class="text-decoration-none"><?php echo e($artik->author->name); ?></a></p>
        <?php else: ?>
            <p>By: Unknown Author</p>
        <?php endif; ?>

        <p><?php echo e($artik->excerpt); ?></p>

        <a href="/artikel/<?php echo e($artik->slug); ?>" class="text-decoration-none">Read More...</a>

    </article>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\artikel.blade.php ENDPATH**/ ?>