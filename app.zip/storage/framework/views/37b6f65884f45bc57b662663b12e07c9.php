<?php $__env->startSection('Halaman awal'); ?>
    <h1>Halaman Acara</h1>
    <h3><?php echo e($nama); ?></h3>
    <p><?php echo e($email); ?></p>
    <img src="img/<?php echo e($image); ?>" alt="<?php echo e($nama); ?>" width="100">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\acara.blade.php ENDPATH**/ ?>