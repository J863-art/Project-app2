<?php $__env->startSection('container'); ?>

<h1>Edit User</h1>

<form action="<?php echo e(route('users.update', $user->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="nik" class="form-label">NIK</label>
        <input type="text" name="nik" id="nik" class="form-control" value="<?php echo e($user->nik); ?>" required>
    </div>

    <div class="mb-3">
        <label for="name" class="form-label">Nama</label>
        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($user->name); ?>" required>
    </div>

    <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" name="username" id="username" class="form-control" value="<?php echo e($user->username); ?>" required>
    </div>

    <div class="mb-3">
        <label for="no_telp" class="form-label">No Telepon</label>
        <input type="text" name="no_telp" id="no_telp" class="form-control" value="<?php echo e($user->no_telp); ?>" required>
    </div>

    <div class="mb-3">
        <label for="password" class="form-label">Password (kosongkan jika tidak diubah)</label>
        <input type="password" name="password" id="password" class="form-control">
    </div>

    <div class="mb-3">
        <label for="role" class="form-label">Role</label>
        <select name="role" id="role" class="form-select" required>
            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>Admin</option>
            <option value="user" <?php echo e($user->role == 'user' ? 'selected' : ''); ?>>User</option>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Update User</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/users/edit.blade.php ENDPATH**/ ?>