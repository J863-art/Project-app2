<?php $__env->startSection('container'); ?>

    <h1>Halaman Acara</h1> <!-- Menampilkan judul yang disediakan oleh controller -->

    <div class="undangan-container" style="display: flex; flex-wrap: wrap; gap: 20px;">

        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="undangan" style="flex: 1 1 calc(50% - 20px); border: 1px solid #ddd; border-radius: 8px; padding: 20px; background-color: #f9f9f9; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);">
                <h2><?php echo e($event->event_name); ?></h2>
                <p><strong>Alamat:</strong> <?php echo e($event->address); ?></p>
                <p><strong>Tanggal:</strong> <?php echo e(\Carbon\Carbon::parse($event->schedule)->format('d-m-Y H:i')); ?></p>
                <p><strong>Keterangan:</strong> <?php echo e($event->ket); ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/events/index.blade.php ENDPATH**/ ?>