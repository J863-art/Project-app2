<?php $__env->startSection('container'); ?>
<div class="container">
    <h1>Tambah Rapat Baru</h1>
    <form action="<?php echo e(route('rapatadmin.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="mb-3">
            <label for="judul" class="form-label">Judul</label>
            <input type="text" class="form-control" id="judul" name="judul" required>
        </div>
        <div class="mb-3">
            <label for="alamat" class="form-label">Lokasi</label>
            <input type="text" class="form-control" id="alamat" name="alamat" required>
        </div>
        <div class="mb-3">
            <label for="keputusan" class="form-label">Keputusan</label>
            <textarea class="form-control" id="keputusan" name="keputusan" required></textarea>
        </div>
        <div class="mb-3">
            <label for="dokumentasi" class="form-label">Dokumentasi (PDF)</label>
            <input type="file" class="form-control" id="dokumentasi" name="dokumentasi" accept="application/pdf">
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/rapatadmin/create.blade.php ENDPATH**/ ?>