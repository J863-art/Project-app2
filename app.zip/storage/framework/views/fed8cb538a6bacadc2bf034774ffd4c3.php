<?php $__env->startSection('container'); ?>
    <div class="container mt-4">
        <div class="card shadow-lg border-primary" style="background-color: #f8f9fa;">
            <div class="card-body">
                <h2 class="card-title"><?php echo e($artik->title); ?></h2>
                <h6 class="card-subtitle mb-2 text-muted">
                    By: <a href="/authors/<?php echo e($artik->author->username); ?>" class="text-decoration-none"><?php echo e($artik->author->name); ?></a>
                    | Created at: <?php echo e($artik->created_at->format('d M Y')); ?>

                </h6>
                <div class="card-text">
                    <?php echo $artik->body; ?>

                </div>
            </div>
        </div>
        <a href="/artikel" class="btn btn-primary mt-3">Back to Artikel</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/artik.blade.php ENDPATH**/ ?>