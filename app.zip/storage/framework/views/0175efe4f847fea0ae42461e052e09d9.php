<?php $__env->startSection('container'); ?>
<div class="container">
    <h2>Detail Tagihan</h2>
    <table class="table">
        <tr>
            <th>NIK</th>
            <td><?php echo e($tagihan->nik); ?></td>
        </tr>
        <tr>
            <th>Jenis Tagihan</th>
            <td><?php echo e($tagihan->jenis_tagihan); ?></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo e($tagihan->status); ?></td>
        </tr>
        <tr>
            <th>Jatuh Tempo</th>
            <td><?php echo e($tagihan->jatuh_tempo); ?></td>
        </tr>
        <tr>
            <th>Bukti Pembayaran</th>
            <td>
                <?php if($tagihan->bukti_pembayaran): ?>
                    <a href="<?php echo e(route('tagihan.download', $tagihan->id)); ?>" class="btn btn-primary">Download Bukti Pembayaran</a>
                <?php else: ?>
                    <span>Tidak ada bukti pembayaran</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>

    <?php if(!$tagihan->bukti_pembayaran): ?>
    <!-- Form untuk upload bukti pembayaran -->
    <form action="<?php echo e(route('tagihan.upload', $tagihan->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="bukti_pembayaran">Upload Bukti Pembayaran (PNG only):</label>
            <input type="file" name="bukti_pembayaran" class="form-control" accept="image/png" required>
        </div>
        <button type="submit" class="btn btn-success mt-2">Upload</button>
    </form>
    <?php endif; ?>

    <?php if($tagihan->bukti_pembayaran): ?>
    <!-- Form untuk edit bukti pembayaran -->
    <form action="<?php echo e(route('tagihan.upload', $tagihan->id)); ?>" method="POST" enctype="multipart/form-data" class="mt-3">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="bukti_pembayaran">Edit Bukti Pembayaran (PNG only):</label>
            <input type="file" name="bukti_pembayaran" class="form-control" accept="image/png" required>
        </div>
        <button type="submit" class="btn btn-warning mt-2">Update</button>
    </form>
    <?php endif; ?>

    <a href="/tagihan" class="btn btn-secondary mt-3">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\tagihan\show.blade.php ENDPATH**/ ?>