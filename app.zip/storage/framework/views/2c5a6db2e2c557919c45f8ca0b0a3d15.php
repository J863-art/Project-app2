<?php $__env->startSection('container'); ?>
<div class="container">
    <ul>
        <li><strong>Tanggal:</strong> <?php echo e($rapat->tanggal); ?></li>
        <li><strong>Judul:</strong> <?php echo e($rapat->judul); ?></li>
        <li><strong>Alamat:</strong> <?php echo e($rapat->alamat); ?></li>
        <li><strong>Keputusan:</strong> <?php echo e($rapat->keputusan); ?></li>
            <?php if($rapat->dokumentasi): ?>
                <p>
                    <strong>Dokumentasi:</strong>
                    <a href="<?php echo e(route('rapat.download', $rapat->id)); ?>" class="btn btn-primary">Download PDF</a>
                </p>
            <?php else: ?>
                <p><strong>Dokumentasi:</strong> Tidak ada dokumentasi tersedia.</p>
            <?php endif; ?>
        </li>
    </ul>
    <a href="<?php echo e(route('rapat.index')); ?>" class="btn btn-primary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\Rapat\detailrapat.blade.php ENDPATH**/ ?>