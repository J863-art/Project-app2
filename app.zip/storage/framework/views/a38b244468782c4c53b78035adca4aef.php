<?php $__env->startSection('container'); ?>

<h1 class="mb-5">Edit Artikel</h1>

<form action="<?php echo e(route('Artikeladmin.update', $artikel->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="title" class="form-label">Judul</label>
        <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $artikel->title)); ?>" required>
    </div>

    <div class="mb-3">
        <label for="excerpt" class="form-label">Excerpt</label>
        <textarea class="form-control" id="excerpt" name="excerpt" required><?php echo e(old('excerpt', $artikel->excerpt)); ?></textarea>
    </div>

    <div class="mb-3">
        <label for="body" class="form-label">Isi</label>
        <textarea class="form-control" id="body" name="body" required><?php echo e(old('body', $artikel->body)); ?></textarea>
    </div>

    <button type="submit" class="btn btn-primary">Update Artikel</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/Artikeladmin/edit.blade.php ENDPATH**/ ?>