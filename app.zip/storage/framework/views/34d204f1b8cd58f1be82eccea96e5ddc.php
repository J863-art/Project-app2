<?php $__env->startSection('Halaman awal'); ?>
<div class="row justify-content-center">
    <div class="col-md-4">

        <?php if(session()->has('loginError')): ?>
            <div class="alert alert-success alert-dismissble fade show" role="alert">
                <?php echo e(session('loginError')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                </button>
            </div>
        <?php endif; ?>

        <main class="form-signin w-100 m-auto">
            <h1 class="h3 mb-3 fw-normal text-center">Please Login</h1>
            <form action="/login" method= "post">
                <?php echo csrf_field(); ?>

              <div class="form-floating">
                <input type="nik" name="nik" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="id" placeholder="123.....nikexample" autofocus required>
                <label for="nik" style="left: 0; padding-left: 1px;">NIK</label>
                <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($mesaage); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="form-floating">
                <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password" autofocus required>
                <label for="floatingPassword" style="left: 0; padding-left: 1px;">Password</label>
              </div>

              <button class="btn btn-primary w-100 py-2" type="submit">Sign in</button>

            </form>
            <small class="d-block text-center mt-3">Admin? <a href="/logadmin">Klik here!</a></small>
        </main>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/login/index.blade.php ENDPATH**/ ?>