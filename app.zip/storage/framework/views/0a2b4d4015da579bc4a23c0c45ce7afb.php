<?php $__env->startSection('container'); ?>
    <article>
        <h2><?php echo e($artik->title); ?></h2>

        <?php if($artik->author): ?>
            <p>By: <a href="/authors/<?php echo e($artik->author->username); ?>" class="text-decoration-none"><?php echo e($artik->author->name); ?></a></p>
        <?php else: ?>
            <p>By: Unknown Author</p>
        <?php endif; ?>

        <?php echo $artik->body; ?>

    </article>

    <a href="/Artikeladmin">Back to Artikel</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/Artikeladmin/show.blade.php ENDPATH**/ ?>