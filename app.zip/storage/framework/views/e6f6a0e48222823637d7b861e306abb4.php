<?php $__env->startSection('container'); ?>
<div class="container">
    <h1>Himbauan</h1>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Keterangan</th>
                <th>Pembuat</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $himbauans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $himbauan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($himbauan->judul); ?></td>
                    <td><?php echo e($himbauan->ket); ?></td>
                    <td><?php echo e($himbauan->created_by); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\himbauan\himbauan.blade.php ENDPATH**/ ?>