<?php $__env->startSection('container'); ?>

    <h1>Halaman Himbauan</h1>

    <!-- Tombol Tambah Himbauan -->
    <a href="<?php echo e(route('himbauanadmin.create')); ?>" class="btn btn-success mb-3">Tambah Himbauan</a>

    <table class="table">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Keterangan/Isi</th>
                <th>Dibuat Oleh</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $himbauan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->judul); ?></td>
                    <td><?php echo e($item->ket); ?></td>
                    <td><?php echo e($item->created_by); ?></td>
                    <td>
                        <!-- Tombol Edit -->
                        <a href="<?php echo e(route('himbauanadmin.edit', $item->id)); ?>" class="btn btn-warning">Edit</a>

                        <form action="<?php echo e(route('himbauanadmin.destroy', $item->id)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus himbauan ini?');" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/himbauanadmin/index.blade.php ENDPATH**/ ?>