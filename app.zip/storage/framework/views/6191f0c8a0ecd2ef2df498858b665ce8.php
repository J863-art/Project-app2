<?php $__env->startSection('container'); ?>
<div class="container">
    <h1 class="my-4">Himbauan</h1>
    <div class="row">
        <?php $__currentLoopData = $himbauans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $himbauan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4"> <!-- Ubah ukuran kolom sesuai kebutuhan -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($himbauan->judul); ?></h5>
                        <p class="card-text"><?php echo e($himbauan->ket); ?></p>
                        <p class="card-text"><small class="text-muted">Dibuat oleh: <?php echo e($himbauan->created_by); ?></small></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/himbauan/himbauan.blade.php ENDPATH**/ ?>