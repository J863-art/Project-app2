<?php $__env->startSection('container'); ?>
<div class="container">
    <h1>Detail Rapat</h1>
    <p><strong>Tanggal:</strong> <?php echo e($rapat->tanggal); ?></p>
    <p><strong>Judul:</strong> <?php echo e($rapat->judul); ?></p>
    <p><strong>Lokasi:</strong> <?php echo e($rapat->alamat); ?></p>
    <p><strong>Keputusan:</strong> <?php echo e($rapat->keputusan); ?></p>

    <?php if($rapat->dokumentasi): ?>
        <p>
            <strong>Dokumentasi:</strong>
            <a href="<?php echo e(route('rapatadmin.download', $rapat->id)); ?>" class="btn btn-primary">Download PDF</a>
        </p>
    <?php else: ?>
        <p><strong>Dokumentasi:</strong> Tidak ada dokumentasi tersedia.</p>
    <?php endif; ?>

    <a href="<?php echo e(route('rapatadmin.index')); ?>" class="btn btn-secondary mt-3">Kembali ke Daftar Rapat</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashmin.layoutin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\rapatadmin\show.blade.php ENDPATH**/ ?>