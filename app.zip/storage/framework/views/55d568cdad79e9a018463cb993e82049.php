<?php $__env->startSection('container'); ?>
<div class="d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="text-center">
        <h1>Anda Belum Login, Login terlebih dahulu untuk melihat tagihan anda</h1>
        <li class="nav-item">
            <a href="/logintagihan" class="nav-link"><i class="bi bi-box-arrow-in-right"></i> Login</a>
        </li>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views\tagihan\default.blade.php ENDPATH**/ ?>