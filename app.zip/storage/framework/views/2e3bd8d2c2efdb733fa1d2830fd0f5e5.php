<?php $__env->startSection('container'); ?>

<div class="bg-white py-24 sm:py-32">
  <div class="mx-auto max-w-7xl px-6 lg:px-8">
    <div class="mx-auto max-w-2xl lg:mx-0">
      <h2 class="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Halaman Artikel</h2>
      <p class="mt-2 text-lg leading-8 text-gray-600">Temukan artikel terbaru kami di bawah ini.</p>
    </div>
    <div class="mx-auto mt-10 grid grid-cols-1 gap-x-8 gap-y-16 sm:grid-cols-2 lg:grid-cols-3">
      <?php $__currentLoopData = $artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artik): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="max-w-sm rounded overflow-hidden shadow-lg">
        <article class="flex flex-col items-start justify-between p-4">
          <div class="flex items-center gap-x-4 text-xs mb-2">
            <time datetime="<?php echo e($artik->created_at->format('Y-m-d')); ?>" class="text-gray-500"><?php echo e($artik->created_at->format('M d, Y')); ?></time>
          </div>
          <div class="group relative">
            <h3 class="mt-2 text-lg font-semibold leading-6 text-gray-900 group-hover:text-gray-600">
              <a href="/artikel/<?php echo e($artik->slug); ?>">
                <span class="absolute inset-0"></span>
                <?php echo e($artik->title); ?>

              </a>
            </h3>
            <?php if($artik->author): ?>
              <p class="mt-1 text-sm leading-6 text-gray-600">
                By: <a href="/authors/<?php echo e($artik->author->username); ?>" class="text-decoration-none"><?php echo e($artik->author->name); ?></a>
              </p>
            <?php else: ?>
              <p class="mt-1 text-sm leading-6 text-gray-600">By: Unknown Author</p>
            <?php endif; ?>
            <p class="mt-5 line-clamp-3 text-sm leading-6 text-gray-600"><?php echo e($artik->excerpt); ?></p>
          </div>
          <div class="relative mt-4">
            <a href="/artikel/<?php echo e($artik->slug); ?>" class="text-decoration-none text-blue-600 hover:underline">Read More...</a>
          </div>
        </article>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Project-app\resources\views/artikel.blade.php ENDPATH**/ ?>