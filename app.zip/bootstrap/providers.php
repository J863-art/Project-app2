<?php

return [
    App\Providers\AppServiceProvider::class,
];
