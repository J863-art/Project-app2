@extends('layout.main')

@section('Halaman awal')
    <h1>Halaman home</h1>
@endsection
